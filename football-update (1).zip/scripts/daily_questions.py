#!/usr/bin/env python3
"""يضيف 100 سؤال جديد كل يوم لمليونير كرة القدم.

- الأسئلة بتتولّد من Claude مع بحث ويب (عشان تواكب أحداث الكورة الحالية).
- كل سؤال بيتفحص: صيغة صحيحة + مش مكرر ولا شبيه بأي سؤال قديم في bank/.
- bank/ = الأرشيف الكامل (ملف لكل يوم). questions.json = اللي اللعبة بتحمّله
  (كل أسئلة آخر 30 يوم + عينة عشوائية من الأقدم، بحد أقصى LIVE_MAX).
"""
import datetime, glob, json, os, random, re, sys, time, urllib.request, urllib.error

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BANK_DIR = os.path.join(ROOT, "bank")
LIVE_FILE = os.path.join(ROOT, "questions.json")

DAILY = int(os.environ.get("DAILY_COUNT", "100"))
LIVE_MAX = int(os.environ.get("LIVE_MAX", "5000"))
RECENT_DAYS = int(os.environ.get("RECENT_DAYS", "30"))
MODEL = os.environ.get("CLAUDE_MODEL") or "claude-sonnet-5-5"
API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MAX_ROUNDS = 14

# مواضيع كل دفعة (بنلف عليها لحد ما نوصل 100)
THEMES = [
    ("أحدث أخبار وأحداث كرة القدم في آخر 7 أيام (نتائج، انتقالات، إصابات، تعيين مدربين، جوائز) — لازم تبحث في الويب", True),
    ("نتائج وأحداث الموسم الحالي في الدوريات الكبرى وأبطال أوروبا والدوريات العربية — ابحث في الويب", True),
    ("كأس العالم وكأس الأمم الأفريقية وكأس أمم آسيا وكوبا أمريكا ويورو: تاريخ وأرقام وأبطال", False),
    ("الكرة المصرية والعربية: الأهلي والزمالك والمنتخب ومحمد صلاح وكبار اللاعبين العرب", False),
    ("أساطير وأرقام قياسية: الكرة الذهبية والأحذية الذهبية وأفضل الهدافين", False),
    ("أندية أوروبا الكبرى وملاعبها وتاريخها ومدربوها ومباريات نهائية شهيرة", False),
    ("لاعبون حاليون: أعمار وأندية ومراكز وإنجازات ومنتخبات", True),
]
LEVELS_RULE = "المستوى: 1 = متوسط، 2 = بين المتوسط والصعب، 3 = صعب شوية (لكن مشهور). وزّعهم تقريباً 35% / 40% / 25%."

SYSTEM = (
    "أنت كاتب أسئلة مسابقة «مَن سيربح المليون» عن كرة القدم للرجال فقط، بالعربية الفصحى المبسطة. "
    "كل سؤال له إجابة صحيحة واحدة مؤكدة ومعروفة، و3 إجابات خاطئة معقولة ومختلفة. "
    "ممنوع الأسئلة الغامضة أو اللي إجابتها محل خلاف، وممنوع التخمين: لو مش متأكد من معلومة اتجاهلها. "
    "أي سؤال مرتبط بوقت لازم يذكر الموسم أو السنة صراحة (مثل: في موسم 2025-26) عشان ما يبقاش غلط بعد كام شهر. "
    "رد بـ JSON فقط، بدون أي شرح وبدون علامات ```."
)


def user_prompt(theme, n, avoid):
    av = "\n".join("- " + q for q in avoid)
    return (
        f"اكتب {n} سؤال جديد تماماً عن: {theme}\n"
        f"الصيغة: مصفوفة JSON، كل عنصر مصفوفة من 6 عناصر بالترتيب: "
        f'["السؤال","الإجابة الصحيحة","خطأ1","خطأ2","خطأ3",المستوى]\n'
        f"{LEVELS_RULE}\n"
        "الإجابات الأربع لازم تكون مختلفة، والإجابة الصحيحة تتكتب مرة واحدة في خانتها فقط.\n"
        "نوّع الأسئلة (لاعبين، أندية، بطولات، أرقام، مدربين) ولا تكرر فكرة السؤال.\n"
        "أمثلة لأسئلة موجودة عندنا — لا تكررها ولا تكتب شبيهاً بها:\n" + av
    )


# ---------- تطبيع وكشف التكرار ----------
_AR_DIAC = re.compile(r"[\u0617-\u061A\u064B-\u0652\u0640]")
_STOP = set("من في على الى إلى عن هو هي ما ماذا هل كم اي أي التي الذي الذين هذا هذه ذلك كان كانت يكون لاعب اللاعب فريق الفريق نادي النادي مع بين بعد قبل خلال عند كل او أو ثم قد لم لا".split())


def norm(s):
    s = _AR_DIAC.sub("", s)
    s = re.sub("[إأآا]", "ا", s)
    s = s.replace("ى", "ي").replace("ة", "ه").replace("ؤ", "و").replace("ئ", "ي")
    s = re.sub(r"[^\w\s]", " ", s.lower())
    return re.sub(r"\s+", " ", s).strip()


def tokens(q):
    return frozenset(t for t in norm(q).split() if t not in _STOP and len(t) > 1)


def valid(r):
    return (isinstance(r, list) and len(r) == 6
            and all(isinstance(x, str) and x.strip() for x in r[:5])
            and len({norm(x) for x in r[1:5]}) == 4
            and isinstance(r[5], int) and 1 <= r[5] <= 3
            and 15 <= len(r[0]) <= 220 and all(len(x) <= 60 for x in r[1:5]))


class Index:
    """فهرس مقلوب للتوكنز عشان الفحص يفضل سريع حتى مع 80 ألف سؤال."""

    def __init__(self):
        self.toks, self.ans, self.inv, self.exact = [], [], {}, set()

    def add(self, r):
        i = len(self.toks)
        t = tokens(r[0])
        self.toks.append(t)
        self.ans.append(norm(r[1]))
        self.exact.add(norm(r[0]))
        for w in t:
            self.inv.setdefault(w, []).append(i)

    def dup(self, r):
        if norm(r[0]) in self.exact:
            return True
        t = tokens(r[0])
        if not t:
            return True
        cnt = {}
        for w in t:
            lst = self.inv.get(w, ())
            if len(lst) > 3000:      # كلمة شائعة جداً، مش مفيدة للمقارنة
                continue
            for i in lst:
                cnt[i] = cnt.get(i, 0) + 1
        a = norm(r[1])
        nums = frozenset(w for w in t if w.isdigit())
        for i, c in cnt.items():
            if c < 2:
                continue
            o = self.toks[i]
            if frozenset(w for w in o if w.isdigit()) != nums:
                continue                 # سنة/رقم مختلف = سؤال مختلف (نفس القالب مسموح)
            j = c / len(t | o)
            # نفس الحقيقة بصياغة تانية (نفس الإجابة) أو نص شبه مطابق
            countish = bool(re.search(r"\d|مره|مرات|مرتين|هدف|اهداف", a))   # إجابات عددية بتتصادف كتير، مش دليل تكرار
            if (j >= 0.5 and self.ans[i] == a and not countish) or j >= 0.9:
                return True
        return False


# ---------- الأرشيف ----------
def load_file(p):
    try:
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
        return [r for r in (d if isinstance(d, list) else d.get("questions", [])) if valid(r)]
    except Exception as e:
        print("skip", p, e)
        return []


def bank_files():
    return sorted(glob.glob(os.path.join(BANK_DIR, "*.json")))


def dump(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, path)


# ---------- Claude ----------
def call_claude(prompt, search):
    body = {"model": MODEL, "max_tokens": 16000, "system": SYSTEM,
            "messages": [{"role": "user", "content": prompt}]}
    if search:
        body["tools"] = [{"type": "web_search_20250305", "name": "web_search", "max_uses": 5}]
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages", data=json.dumps(body).encode(),
        headers={"content-type": "application/json", "x-api-key": API_KEY,
                 "anthropic-version": "2023-06-01"})
    with urllib.request.urlopen(req, timeout=600) as res:
        data = json.load(res)
    return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")


def parse(text):
    a, b = text.find("["), text.rfind("]")
    if a < 0 or b <= a:
        return []
    try:
        arr = json.loads(text[a:b + 1])
    except Exception:
        return []
    return [[(x.strip() if isinstance(x, str) else x) for x in r] for r in arr if isinstance(r, list)]


def generate(batch_size, theme, search, avoid):
    for attempt in range(3):
        try:
            return parse(call_claude(user_prompt(theme, batch_size, avoid), search))
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            print("API error:", e, "- retry")
            time.sleep(10 * (attempt + 1))
    return []


# ---------- ملف اللعبة ----------
def build_live(today):
    files = bank_files()
    recent, older = [], []
    cutoff = today - datetime.timedelta(days=RECENT_DAYS)
    for p in files:
        name = os.path.basename(p)[:-5]
        try:
            d = datetime.date.fromisoformat(name)
        except ValueError:
            d = None
        (recent if d and d >= cutoff else older).extend(load_file(p))
    room = max(0, LIVE_MAX - len(recent))
    rnd = random.Random(today.toordinal())     # عينة مختلفة كل يوم
    sample = older if len(older) <= room else rnd.sample(older, room)
    live = recent + sample
    dump(LIVE_FILE, live)
    return len(live), len(recent), len(older)


def main():
    today = datetime.datetime.now(datetime.timezone.utc).date()
    idx, recent_q = Index(), []
    for p in bank_files():
        for r in load_file(p):
            idx.add(r)
            recent_q.append(r[0])
    total_before = len(idx.toks)
    day_path = os.path.join(BANK_DIR, today.isoformat() + ".json")
    todays = load_file(day_path) if os.path.exists(day_path) else []
    need = DAILY - len(todays)
    print(f"bank={total_before} today_so_far={len(todays)} need={need}")

    if need > 0 and not API_KEY:
        sys.exit("ANTHROPIC_API_KEY مش موجود في Secrets")

    rounds = 0
    while need > 0 and rounds < MAX_ROUNDS:
        theme, search = THEMES[rounds % len(THEMES)]
        rounds += 1
        avoid = random.sample(recent_q, min(40, len(recent_q)))
        got = generate(min(need + 8, 30), theme, search, avoid)
        added = 0
        for r in got:
            if need <= 0:
                break
            if valid(r) and not idx.dup(r):
                idx.add(r); todays.append(r); recent_q.append(r[0]); need -= 1; added += 1
        print(f"round {rounds}: got={len(got)} added={added} remaining={max(need,0)}")
        if added:
            dump(day_path, todays)           # نحفظ بعد كل دفعة عشان ما نخسرش شغل

    n_live, n_recent, n_old = build_live(today)
    print(f"added today={len(todays)} | bank total={len(idx.toks)} | live={n_live} (recent {n_recent}, older pool {n_old})")
    if not todays:
        sys.exit("ماتولّدش ولا سؤال النهارده")


if __name__ == "__main__":
    main()
